package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.preferences.UserPreferences
import com.example.data.remote.AiProviderService
import com.example.data.repository.CreationRepository

class NanoVisionApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: CreationRepository
        private set

    lateinit var userPreferences: UserPreferences
        private set

    lateinit var aiProviderService: AiProviderService
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = AppDatabase.getInstance(this)
        repository = CreationRepository(database.creationDao())
        userPreferences = UserPreferences(this)
        aiProviderService = AiProviderService()
    }

    companion object {
        lateinit var instance: NanoVisionApp
            private set
    }
}
