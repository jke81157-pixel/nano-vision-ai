package com.example.domain.models

data class AiModelInfo(
    val id: String,
    val name: String,
    val tag: String,
    val description: String,
    val type: ModelType,
    val isPaidQuota: Boolean = true,
    val supportedAspectRatios: List<String> = listOf("1:1", "16:9", "9:16", "4:3", "3:4"),
    val supportedResolutions: List<String> = listOf("720p", "1080p", "4K"),
    val supportedDurations: List<Int> = listOf(5, 10, 15),
    val supportsAudio: Boolean = false,
    val supportsImageToVideo: Boolean = false
)

enum class ModelType {
    IMAGE, VIDEO, TEXT
}

object AiModelRegistry {
    val imageModels = listOf(
        AiModelInfo(
            id = "gemini-2.5-flash-image",
            name = "Nano Banana (Gemini 2.5 Flash Image)",
            tag = "Fast & Creative",
            description = "Google's ultra-responsive multimodal image generation model with high dynamic range.",
            type = ModelType.IMAGE,
            isPaidQuota = false,
            supportedAspectRatios = listOf("1:1", "16:9", "9:16", "4:3", "3:4")
        ),
        AiModelInfo(
            id = "gemini-3.1-flash-image-preview",
            name = "Nano Banana 2 (Gemini 3.1 Flash Image)",
            tag = "High Definition",
            description = "Advanced neural synthesis supporting 1K, 2K and 4K output fidelity.",
            type = ModelType.IMAGE,
            isPaidQuota = true,
            supportedAspectRatios = listOf("1:1", "16:9", "9:16", "4:3", "3:4")
        ),
        AiModelInfo(
            id = "gemini-3-pro-image-preview",
            name = "Nano Banana Pro (Gemini 3 Pro Image)",
            tag = "Studio Master",
            description = "Maximum realism, intricate texture details, and cinematic composition.",
            type = ModelType.IMAGE,
            isPaidQuota = true,
            supportedAspectRatios = listOf("1:1", "16:9", "9:16", "4:3", "3:4")
        )
    )

    val videoModels = listOf(
        AiModelInfo(
            id = "veo-3.1-fast-generate-preview",
            name = "Veo Fast (Veo 3.1 Fast)",
            tag = "Rapid Motion",
            description = "High-speed cinematic video synthesis with fluid temporal consistency.",
            type = ModelType.VIDEO,
            isPaidQuota = true,
            supportedAspectRatios = listOf("16:9", "9:16"),
            supportedResolutions = listOf("720p", "1080p"),
            supportedDurations = listOf(5, 10),
            supportsAudio = true,
            supportsImageToVideo = true
        ),
        AiModelInfo(
            id = "veo-3.1-generate-preview",
            name = "Veo 3 Cinematic (Veo 3.1 Generate)",
            tag = "Cinematic 4K",
            description = "Studio-grade neural video generation with physics-accurate motion and volumetric lighting.",
            type = ModelType.VIDEO,
            isPaidQuota = true,
            supportedAspectRatios = listOf("16:9", "9:16"),
            supportedResolutions = listOf("1080p", "4K"),
            supportedDurations = listOf(5, 10, 15),
            supportsAudio = true,
            supportsImageToVideo = true
        )
    )

    val styles = listOf(
        "Photorealistic",
        "Cyberpunk Neon",
        "Anime / Manga",
        "3D Digital Render",
        "Cinematic Movie Still",
        "Oil Painting",
        "Concept Art",
        "Sci-Fi Hologram",
        "Minimalist Vector",
        "Fantasy Epic"
    )

    val aspectRatios = listOf(
        AspectRatioOption("1:1", "Square", "1024x1024"),
        AspectRatioOption("16:9", "Landscape", "1920x1080"),
        AspectRatioOption("9:16", "Portrait (Reel)", "1080x1920"),
        AspectRatioOption("4:3", "Standard", "1024x768"),
        AspectRatioOption("3:4", "Editorial", "768x1024")
    )
}

data class AspectRatioOption(
    val ratio: String,
    val label: String,
    val resolutionLabel: String
)

data class GenerationResult(
    val isSuccess: Boolean,
    val mediaType: String,
    val mediaUrl: String? = null,
    val base64Data: String? = null,
    val prompt: String,
    val modelId: String,
    val errorMessage: String? = null
)

data class PromptEnhanceResult(
    val originalPrompt: String,
    val enhancedPrompt: String,
    val styleAdded: String,
    val cameraKeywords: String
)
