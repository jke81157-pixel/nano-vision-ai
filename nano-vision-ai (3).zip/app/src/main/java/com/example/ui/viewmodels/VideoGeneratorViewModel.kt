package com.example.ui.viewmodels

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.NanoVisionApp
import com.example.data.local.CreationEntity
import com.example.domain.models.AiModelInfo
import com.example.domain.models.AiModelRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

data class VideoGenUiState(
    val prompt: String = "",
    val enhancedPrompt: String? = null,
    val isEnhancing: Boolean = false,
    val isGenerating: Boolean = false,
    val generationProgress: Float = 0f,
    val progressStage: String = "",
    val selectedModel: AiModelInfo = AiModelRegistry.videoModels.first(),
    val availableModels: List<AiModelInfo> = AiModelRegistry.videoModels,
    val selectedDuration: Int = 5,
    val selectedResolution: String = "1080p",
    val selectedAspectRatio: String = "16:9",
    val isAudioEnabled: Boolean = true,
    val seedImageUri: String? = null,
    val seedImageBase64: String? = null,
    val generatedCreation: CreationEntity? = null,
    val isPlaying: Boolean = true,
    val playbackProgress: Float = 0f,
    val isMuted: Boolean = false,
    val errorMessage: String? = null,
    val showQuotaWarning: Boolean = false,
    val pendingGenerationPrompt: String? = null
)

class VideoGeneratorViewModel : ViewModel() {

    private val repository = NanoVisionApp.instance.repository
    private val aiService = NanoVisionApp.instance.aiProviderService

    private val _uiState = MutableStateFlow(VideoGenUiState())
    val uiState: StateFlow<VideoGenUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        loadAvailableModels()
    }

    private fun loadAvailableModels() {
        viewModelScope.launch {
            val models = aiService.getAvailableModels().filter { it.type == com.example.domain.models.ModelType.VIDEO }
            if (models.isNotEmpty()) {
                _uiState.update {
                    it.copy(
                        availableModels = models,
                        selectedModel = models.first()
                    )
                }
            }
        }
    }

    fun onPromptChange(newPrompt: String) {
        _uiState.update { it.copy(prompt = newPrompt, errorMessage = null) }
    }

    fun onModelSelected(model: AiModelInfo) {
        _uiState.update {
            it.copy(
                selectedModel = model,
                selectedResolution = if (model.supportedResolutions.contains(it.selectedResolution)) it.selectedResolution else model.supportedResolutions.first(),
                selectedDuration = if (model.supportedDurations.contains(it.selectedDuration)) it.selectedDuration else model.supportedDurations.first()
            )
        }
    }

    fun onDurationSelected(duration: Int) {
        _uiState.update { it.copy(selectedDuration = duration) }
    }

    fun onResolutionSelected(res: String) {
        _uiState.update { it.copy(selectedResolution = res) }
    }

    fun onAspectRatioSelected(ratio: String) {
        _uiState.update { it.copy(selectedAspectRatio = ratio) }
    }

    fun onAudioToggle(enabled: Boolean) {
        _uiState.update { it.copy(isAudioEnabled = enabled) }
    }

    fun setSeedImage(uri: String?, base64: String?) {
        _uiState.update { it.copy(seedImageUri = uri, seedImageBase64 = base64) }
    }

    fun enhancePrompt() {
        val currentPrompt = _uiState.value.prompt.trim()
        if (currentPrompt.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isEnhancing = true, errorMessage = null) }
            val result = aiService.enhancePrompt(currentPrompt, "CINEMATIC VIDEO")
            result.onSuccess { res ->
                _uiState.update {
                    it.copy(
                        prompt = res.enhancedPrompt,
                        enhancedPrompt = res.enhancedPrompt,
                        isEnhancing = false
                    )
                }
                _events.emit("Veo video prompt enhanced with cinematic motion direction!")
            }.onFailure { err ->
                _uiState.update { it.copy(isEnhancing = false, errorMessage = err.message) }
            }
        }
    }

    fun initiateGenerate() {
        val prompt = _uiState.value.prompt.trim()
        if (prompt.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a prompt to generate Veo video.") }
            return
        }

        // Show quota confirmation for paid models
        if (_uiState.value.selectedModel.isPaidQuota) {
            _uiState.update { it.copy(showQuotaWarning = true, pendingGenerationPrompt = prompt) }
        } else {
            executeGenerate(prompt)
        }
    }

    fun confirmQuotaWarning() {
        val pending = _uiState.value.pendingGenerationPrompt ?: _uiState.value.prompt
        _uiState.update { it.copy(showQuotaWarning = false, pendingGenerationPrompt = null) }
        executeGenerate(pending)
    }

    fun dismissQuotaWarning() {
        _uiState.update { it.copy(showQuotaWarning = false, pendingGenerationPrompt = null) }
    }

    private fun executeGenerate(prompt: String) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGenerating = true,
                    generationProgress = 0.05f,
                    progressStage = "Initializing Veo 3 Neural Motion Engine...",
                    errorMessage = null
                )
            }

            val stages = listOf(
                Pair(0.20f, "Synthesizing latent 3D spatio-temporal dynamics..."),
                Pair(0.45f, "Interpolating fluid motion vectors & camera dolly..."),
                Pair(0.70f, "Rendering ${_uiState.value.selectedResolution} high-fidelity frames..."),
                Pair(0.90f, "Mastering AI spatial soundtrack & audio FX..."),
                Pair(0.98f, "Finalizing MP4 container & codec compression...")
            )

            for (stage in stages) {
                delay(600)
                _uiState.update {
                    it.copy(
                        generationProgress = stage.first,
                        progressStage = stage.second
                    )
                }
            }

            val result = aiService.generateVideo(
                prompt = prompt,
                modelId = _uiState.value.selectedModel.id,
                durationSeconds = _uiState.value.selectedDuration,
                resolution = _uiState.value.selectedResolution,
                aspectRatio = _uiState.value.selectedAspectRatio,
                hasAudio = _uiState.value.isAudioEnabled,
                seedImageBase64 = _uiState.value.seedImageBase64
            )

            if (result.isSuccess) {
                val entity = CreationEntity(
                    prompt = prompt,
                    enhancedPrompt = _uiState.value.enhancedPrompt,
                    mediaType = "VIDEO",
                    mediaUrl = result.mediaUrl,
                    base64Data = result.base64Data,
                    modelName = _uiState.value.selectedModel.id,
                    modelDisplayName = _uiState.value.selectedModel.name,
                    aspectRatio = _uiState.value.selectedAspectRatio,
                    durationSeconds = _uiState.value.selectedDuration,
                    resolution = _uiState.value.selectedResolution,
                    hasAudio = _uiState.value.isAudioEnabled,
                    seedImageUri = _uiState.value.seedImageUri,
                    timestamp = System.currentTimeMillis()
                )

                val id = repository.insertCreation(entity)
                val savedEntity = entity.copy(id = id)

                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        generationProgress = 1f,
                        progressStage = "Complete",
                        generatedCreation = savedEntity,
                        isPlaying = true,
                        playbackProgress = 0f
                    )
                }
                _events.emit("Veo video rendered successfully!")
            } else {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        errorMessage = result.errorMessage ?: "Failed to generate video."
                    )
                }
            }
        }
    }

    fun togglePlayback() {
        _uiState.update { it.copy(isPlaying = !it.isPlaying) }
    }

    fun updatePlaybackProgress(progress: Float) {
        _uiState.update { it.copy(playbackProgress = progress.coerceIn(0f, 1f)) }
    }

    fun toggleMute() {
        _uiState.update { it.copy(isMuted = !it.isMuted) }
    }

    fun toggleFavorite() {
        val current = _uiState.value.generatedCreation ?: return
        viewModelScope.launch {
            val updatedStatus = !current.isFavorite
            repository.toggleFavorite(current.id, updatedStatus)
            _uiState.update { it.copy(generatedCreation = current.copy(isFavorite = updatedStatus)) }
        }
    }

    fun shareCreation(context: Context) {
        val creation = _uiState.value.generatedCreation ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Created with NANO VISION AI Veo: ${creation.prompt}\nModel: ${creation.modelDisplayName}")
        }
        context.startActivity(Intent.createChooser(intent, "Share Veo Video"))
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}
