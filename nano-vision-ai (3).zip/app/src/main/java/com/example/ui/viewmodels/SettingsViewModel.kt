package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.NanoVisionApp
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppThemeMode
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val defaultImageModel: String = "gemini-2.5-flash-image",
    val defaultVideoModel: String = "veo-3.1-fast-generate-preview",
    val defaultAspectRatio: String = "1:1",
    val notificationsEnabled: Boolean = true,
    val isClearHistoryDialogVisible: Boolean = false,
    val isPrivacyDialogVisible: Boolean = false
)

class SettingsViewModel : ViewModel() {

    private val userPrefs = NanoVisionApp.instance.userPreferences
    private val repository = NanoVisionApp.instance.repository

    private val _uiState = MutableStateFlow(
        SettingsUiState(
            themeMode = userPrefs.themeMode.value,
            language = userPrefs.language.value,
            defaultImageModel = userPrefs.defaultImageModel.value,
            defaultVideoModel = userPrefs.defaultVideoModel.value,
            defaultAspectRatio = userPrefs.defaultAspectRatio.value,
            notificationsEnabled = userPrefs.notificationsEnabled.value
        )
    )
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    fun setThemeMode(mode: AppThemeMode) {
        userPrefs.setThemeMode(mode)
        _uiState.update { it.copy(themeMode = mode) }
    }

    fun setLanguage(lang: AppLanguage) {
        userPrefs.setLanguage(lang)
        _uiState.update { it.copy(language = lang) }
    }

    fun setDefaultImageModel(model: String) {
        userPrefs.setDefaultImageModel(model)
        _uiState.update { it.copy(defaultImageModel = model) }
    }

    fun setDefaultVideoModel(model: String) {
        userPrefs.setDefaultVideoModel(model)
        _uiState.update { it.copy(defaultVideoModel = model) }
    }

    fun setDefaultAspectRatio(aspect: String) {
        userPrefs.setDefaultAspectRatio(aspect)
        _uiState.update { it.copy(defaultAspectRatio = aspect) }
    }

    fun toggleNotifications(enabled: Boolean) {
        userPrefs.setNotificationsEnabled(enabled)
        _uiState.update { it.copy(notificationsEnabled = enabled) }
    }

    fun showClearHistoryDialog(show: Boolean) {
        _uiState.update { it.copy(isClearHistoryDialogVisible = show) }
    }

    fun showPrivacyDialog(show: Boolean) {
        _uiState.update { it.copy(isPrivacyDialogVisible = show) }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
            _uiState.update { it.copy(isClearHistoryDialogVisible = false) }
            _events.emit("All creation history cleared.")
        }
    }
}
