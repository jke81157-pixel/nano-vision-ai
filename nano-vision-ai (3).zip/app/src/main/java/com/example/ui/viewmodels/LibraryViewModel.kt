package com.example.ui.viewmodels

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.NanoVisionApp
import com.example.data.local.CreationEntity
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class LibraryTab {
    ALL, IMAGES, VIDEOS, FAVORITES
}

data class LibraryUiState(
    val selectedTab: LibraryTab = LibraryTab.ALL,
    val searchQuery: String = "",
    val selectedModelFilter: String? = null,
    val isGridView: Boolean = true,
    val selectedCreation: CreationEntity? = null
)

class LibraryViewModel : ViewModel() {

    private val repository = NanoVisionApp.instance.repository

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    val filteredCreations: StateFlow<List<CreationEntity>> = combine(
        repository.allCreations,
        _uiState
    ) { creations, state ->
        creations.filter { item ->
            val matchesTab = when (state.selectedTab) {
                LibraryTab.ALL -> true
                LibraryTab.IMAGES -> item.mediaType == "IMAGE"
                LibraryTab.VIDEOS -> item.mediaType == "VIDEO"
                LibraryTab.FAVORITES -> item.isFavorite
            }

            val matchesSearch = if (state.searchQuery.isBlank()) true else {
                item.prompt.contains(state.searchQuery, ignoreCase = true) ||
                        item.modelDisplayName.contains(state.searchQuery, ignoreCase = true) ||
                        (item.style?.contains(state.searchQuery, ignoreCase = true) ?: false)
            }

            val matchesModel = if (state.selectedModelFilter == null) true else {
                item.modelName == state.selectedModelFilter
            }

            matchesTab && matchesSearch && matchesModel
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onTabSelected(tab: LibraryTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun onModelFilterSelected(model: String?) {
        _uiState.update { it.copy(selectedModelFilter = model) }
    }

    fun toggleViewMode() {
        _uiState.update { it.copy(isGridView = !it.isGridView) }
    }

    fun selectCreation(creation: CreationEntity?) {
        _uiState.update { it.copy(selectedCreation = creation) }
    }

    fun toggleFavorite(creation: CreationEntity) {
        viewModelScope.launch {
            val updated = !creation.isFavorite
            repository.toggleFavorite(creation.id, updated)
            if (_uiState.value.selectedCreation?.id == creation.id) {
                _uiState.update { it.copy(selectedCreation = creation.copy(isFavorite = updated)) }
            }
        }
    }

    fun deleteCreation(creation: CreationEntity) {
        viewModelScope.launch {
            repository.deleteCreation(creation)
            if (_uiState.value.selectedCreation?.id == creation.id) {
                _uiState.update { it.copy(selectedCreation = null) }
            }
            _events.emit("Creation deleted.")
        }
    }

    fun shareCreation(context: Context, creation: CreationEntity) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Prompt: ${creation.prompt}\nModel: ${creation.modelDisplayName}\nCreated with NANO VISION AI")
        }
        context.startActivity(Intent.createChooser(intent, "Share Creation"))
    }
}
