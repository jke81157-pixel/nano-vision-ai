package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.NanoVisionApp
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppThemeMode
import com.example.ui.navigation.Screen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NanoVisionTheme
import com.example.ui.theme.NeonPurple
import com.example.ui.viewmodels.ImageGeneratorViewModel
import com.example.ui.viewmodels.LibraryViewModel
import com.example.ui.viewmodels.SettingsViewModel
import com.example.ui.viewmodels.VideoGeneratorViewModel

@Composable
fun MainAppScaffold() {
    val userPrefs = NanoVisionApp.instance.userPreferences
    val themeMode by userPrefs.themeMode.collectAsStateWithLifecycle()
    val language by userPrefs.language.collectAsStateWithLifecycle()

    val isDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val layoutDirection = if (language == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

    NanoVisionTheme(darkTheme = isDark) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            MainAppContent()
        }
    }
}

@Composable
private fun MainAppContent() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }

    val imageViewModel: ImageGeneratorViewModel = viewModel()
    val videoViewModel: VideoGeneratorViewModel = viewModel()
    val libraryViewModel: LibraryViewModel = viewModel()
    val settingsViewModel: SettingsViewModel = viewModel()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 600.dp

        Scaffold(
            bottomBar = {
                if (!isExpanded) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bottom_navigation_bar")
                    ) {
                        Screen.navItems.forEach { screen ->
                            val isSelected = currentScreen == screen
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { currentScreen = screen },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                        contentDescription = stringResource(screen.titleRes),
                                        modifier = Modifier.size(24.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(screen.titleRes),
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    indicatorColor = CyberCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_${screen.route}")
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Adaptive Navigation Rail for Tablets / Wide screens
                if (isExpanded) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        header = {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(CyberCyan, NeonPurple))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "NANO VISION",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyberCyan
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("navigation_rail")
                    ) {
                        Screen.navItems.forEach { screen ->
                            val isSelected = currentScreen == screen
                            NavigationRailItem(
                                selected = isSelected,
                                onClick = { currentScreen = screen },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                        contentDescription = stringResource(screen.titleRes)
                                    )
                                },
                                label = { Text(stringResource(screen.titleRes), fontSize = 11.sp) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    indicatorColor = CyberCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("rail_item_${screen.route}")
                            )
                        }
                    }
                }

                // Active Screen Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    when (currentScreen) {
                        Screen.Home -> HomeScreen(
                            onNavigateToImage = { currentScreen = Screen.ImageGen },
                            onNavigateToVideo = { currentScreen = Screen.VideoGen },
                            onNavigateToLibrary = { currentScreen = Screen.Library },
                            onSelectCreation = { creation ->
                                libraryViewModel.selectCreation(creation)
                                currentScreen = Screen.Library
                            }
                        )
                        Screen.ImageGen -> ImageGeneratorScreen(
                            viewModel = imageViewModel,
                            onNavigateToVideoWithSeed = { creation ->
                                videoViewModel.setSeedImage(creation.mediaUrl, creation.base64Data)
                                if (videoViewModel.uiState.value.prompt.isBlank()) {
                                    videoViewModel.onPromptChange("Animate this: ${creation.prompt}, cinematic fluid motion")
                                }
                                currentScreen = Screen.VideoGen
                            },
                            onSelectCreation = { creation ->
                                libraryViewModel.selectCreation(creation)
                                currentScreen = Screen.Library
                            }
                        )
                        Screen.VideoGen -> VideoGeneratorScreen(
                            viewModel = videoViewModel
                        )
                        Screen.Library -> LibraryScreen(
                            viewModel = libraryViewModel,
                            onNavigateToImage = { currentScreen = Screen.ImageGen },
                            onNavigateToVideoWithSeed = { creation ->
                                videoViewModel.setSeedImage(creation.mediaUrl, creation.base64Data)
                                videoViewModel.onPromptChange("Animate this: ${creation.prompt}, 4K motion dynamics")
                                currentScreen = Screen.VideoGen
                            },
                            onRegenerate = { prompt ->
                                imageViewModel.onPromptChange(prompt)
                                currentScreen = Screen.ImageGen
                            }
                        )
                        Screen.Settings -> SettingsScreen(
                            viewModel = settingsViewModel
                        )
                    }
                }
            }
        }
    }
}
