package com.example.ui.viewmodels

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.NanoVisionApp
import com.example.data.local.CreationEntity
import com.example.domain.models.AiModelInfo
import com.example.domain.models.AiModelRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ImageGenUiState(
    val prompt: String = "",
    val enhancedPrompt: String? = null,
    val isEnhancing: Boolean = false,
    val isGenerating: Boolean = false,
    val progressStep: String = "",
    val selectedModel: AiModelInfo = AiModelRegistry.imageModels.first(),
    val availableModels: List<AiModelInfo> = AiModelRegistry.imageModels,
    val selectedAspectRatio: String = "1:1",
    val imageCount: Int = 1,
    val selectedQuality: String = "High (1080p)",
    val selectedStyle: String = "Photorealistic",
    val generatedCreations: List<CreationEntity> = emptyList(),
    val errorMessage: String? = null,
    val showQuotaWarning: Boolean = false,
    val pendingGenerationPrompt: String? = null
)

class ImageGeneratorViewModel : ViewModel() {

    private val repository = NanoVisionApp.instance.repository
    private val aiService = NanoVisionApp.instance.aiProviderService

    private val _uiState = MutableStateFlow(ImageGenUiState())
    val uiState: StateFlow<ImageGenUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        loadAvailableModels()
    }

    private fun loadAvailableModels() {
        viewModelScope.launch {
            val models = aiService.getAvailableModels().filter { it.type == com.example.domain.models.ModelType.IMAGE }
            if (models.isNotEmpty()) {
                _uiState.update {
                    it.copy(
                        availableModels = models,
                        selectedModel = models.first()
                    )
                }
            }
        }
    }

    fun onPromptChange(newPrompt: String) {
        _uiState.update { it.copy(prompt = newPrompt, errorMessage = null) }
    }

    fun onModelSelected(model: AiModelInfo) {
        _uiState.update { it.copy(selectedModel = model) }
    }

    fun onAspectRatioSelected(ratio: String) {
        _uiState.update { it.copy(selectedAspectRatio = ratio) }
    }

    fun onImageCountSelected(count: Int) {
        _uiState.update { it.copy(imageCount = count) }
    }

    fun onQualitySelected(quality: String) {
        _uiState.update { it.copy(selectedQuality = quality) }
    }

    fun onStyleSelected(style: String) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun enhancePrompt() {
        val currentPrompt = _uiState.value.prompt.trim()
        if (currentPrompt.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isEnhancing = true, errorMessage = null) }
            val result = aiService.enhancePrompt(currentPrompt, "IMAGE")
            result.onSuccess { res ->
                _uiState.update {
                    it.copy(
                        prompt = res.enhancedPrompt,
                        enhancedPrompt = res.enhancedPrompt,
                        isEnhancing = false
                    )
                }
                _events.emit("Prompt enhanced with cinematic keywords!")
            }.onFailure { err ->
                _uiState.update { it.copy(isEnhancing = false, errorMessage = err.message) }
            }
        }
    }

    fun initiateGenerate() {
        val prompt = _uiState.value.prompt.trim()
        if (prompt.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a prompt to generate imagery.") }
            return
        }

        // Show quota confirmation for models
        if (_uiState.value.selectedModel.isPaidQuota) {
            _uiState.update { it.copy(showQuotaWarning = true, pendingGenerationPrompt = prompt) }
        } else {
            executeGenerate(prompt)
        }
    }

    fun confirmQuotaWarning() {
        val pending = _uiState.value.pendingGenerationPrompt ?: _uiState.value.prompt
        _uiState.update { it.copy(showQuotaWarning = false, pendingGenerationPrompt = null) }
        executeGenerate(pending)
    }

    fun dismissQuotaWarning() {
        _uiState.update { it.copy(showQuotaWarning = false, pendingGenerationPrompt = null) }
    }

    private fun executeGenerate(prompt: String) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGenerating = true,
                    progressStep = "Initializing neural weights...",
                    errorMessage = null
                )
            }

            delay(300)
            _uiState.update { it.copy(progressStep = "Synthesizing visual latent vectors...") }
            delay(400)
            _uiState.update { it.copy(progressStep = "Applying style textures & 8K detail...") }

            val count = _uiState.value.imageCount
            val createdList = mutableListOf<CreationEntity>()

            for (i in 1..count) {
                _uiState.update { it.copy(progressStep = "Rendering frame $i of $count...") }
                val result = aiService.generateImage(
                    prompt = prompt,
                    modelId = _uiState.value.selectedModel.id,
                    aspectRatio = _uiState.value.selectedAspectRatio,
                    style = _uiState.value.selectedStyle,
                    quality = _uiState.value.selectedQuality
                )

                if (result.isSuccess) {
                    val entity = CreationEntity(
                        prompt = prompt,
                        enhancedPrompt = _uiState.value.enhancedPrompt,
                        mediaType = "IMAGE",
                        base64Data = result.base64Data,
                        modelName = _uiState.value.selectedModel.id,
                        modelDisplayName = _uiState.value.selectedModel.name,
                        aspectRatio = _uiState.value.selectedAspectRatio,
                        style = _uiState.value.selectedStyle,
                        quality = _uiState.value.selectedQuality,
                        timestamp = System.currentTimeMillis()
                    )
                    val id = repository.insertCreation(entity)
                    createdList.add(entity.copy(id = id))
                } else {
                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            errorMessage = result.errorMessage ?: "Failed to generate image."
                        )
                    }
                    return@launch
                }
            }

            _uiState.update {
                it.copy(
                    isGenerating = false,
                    progressStep = "",
                    generatedCreations = createdList + it.generatedCreations
                )
            }
            _events.emit("Generation Complete! ${createdList.size} image(s) created.")
        }
    }

    fun toggleFavorite(creation: CreationEntity) {
        viewModelScope.launch {
            val updatedStatus = !creation.isFavorite
            repository.toggleFavorite(creation.id, updatedStatus)
            _uiState.update { state ->
                val updated = state.generatedCreations.map {
                    if (it.id == creation.id) it.copy(isFavorite = updatedStatus) else it
                }
                state.copy(generatedCreations = updated)
            }
        }
    }

    fun shareCreation(context: Context, creation: CreationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val base64 = creation.base64Data ?: return@launch
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val file = File(context.cacheDir, "nano_vision_${creation.id}.png")
                FileOutputStream(file).use { it.write(bytes) }

                val uri = androidx.core.content.FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, "Created with NANO VISION AI: ${creation.prompt}")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share Masterpiece"))
            } catch (e: Exception) {
                // Fallback text share
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Prompt: ${creation.prompt}\nModel: ${creation.modelDisplayName}\nCreated with NANO VISION AI")
                }
                context.startActivity(Intent.createChooser(intent, "Share Prompt"))
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}
