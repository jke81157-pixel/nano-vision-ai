package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Dark Theme Colors (Default Futuristic AI SaaS)
val DarkBackground = Color(0xFF0A0C13)
val DarkSurface = Color(0xFF121624)
val DarkSurfaceVariant = Color(0xFF1A1F33)
val DarkSurfaceElevated = Color(0xFF222842)
val DarkBorder = Color(0xFF2D3552)

val CyberCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFF8B5CF6)
val ElectricViolet = Color(0xFFA855F7)
val GlowPink = Color(0xFFFF2E93)
val EmeraldGreen = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CrimsonError = Color(0xFFEF4444)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceElevated = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)

val PrimaryLight = Color(0xFF6366F1)
val SecondaryLight = Color(0xFF0284C7)
val TertiaryLight = Color(0xFF9333EA)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextTertiaryLight = Color(0xFF94A3B8)

// Gradients
val PrimaryAiGradient = Brush.horizontalGradient(
    colors = listOf(CyberCyan, NeonPurple, GlowPink)
)

val GlowCardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF1F253E), Color(0xFF121624))
)

val VideoGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))
)

val ImageGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF06B6D4), Color(0xFF3B82F6))
)
