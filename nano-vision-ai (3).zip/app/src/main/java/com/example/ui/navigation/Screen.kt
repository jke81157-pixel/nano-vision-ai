package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R

sealed class Screen(
    val route: String,
    val titleRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Home : Screen(
        route = "home",
        titleRes = R.string.nav_home,
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    )

    data object ImageGen : Screen(
        route = "image_gen",
        titleRes = R.string.nav_image,
        selectedIcon = Icons.Filled.Image,
        unselectedIcon = Icons.Outlined.Image
    )

    data object VideoGen : Screen(
        route = "video_gen",
        titleRes = R.string.nav_video,
        selectedIcon = Icons.Filled.Videocam,
        unselectedIcon = Icons.Outlined.Videocam
    )

    data object Library : Screen(
        route = "library",
        titleRes = R.string.nav_library,
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Filled.AutoAwesome
    )

    data object Settings : Screen(
        route = "settings",
        titleRes = R.string.nav_settings,
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )

    companion object {
        val navItems: List<Screen>
            get() = listOf(Home, ImageGen, VideoGen, Library, Settings)
    }
}
