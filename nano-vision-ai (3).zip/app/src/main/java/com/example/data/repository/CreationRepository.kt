package com.example.data.repository

import com.example.data.local.CreationDao
import com.example.data.local.CreationEntity
import kotlinx.coroutines.flow.Flow

class CreationRepository(private val creationDao: CreationDao) {

    val allCreations: Flow<List<CreationEntity>> = creationDao.getAllCreations()
    val imageCreations: Flow<List<CreationEntity>> = creationDao.getImageCreations()
    val videoCreations: Flow<List<CreationEntity>> = creationDao.getVideoCreations()
    val favoriteCreations: Flow<List<CreationEntity>> = creationDao.getFavoriteCreations()

    fun searchCreations(query: String): Flow<List<CreationEntity>> =
        creationDao.searchCreations(query)

    suspend fun getCreationById(id: Long): CreationEntity? =
        creationDao.getCreationById(id)

    suspend fun insertCreation(creation: CreationEntity): Long =
        creationDao.insertCreation(creation)

    suspend fun updateCreation(creation: CreationEntity) =
        creationDao.updateCreation(creation)

    suspend fun toggleFavorite(id: Long, isFav: Boolean) =
        creationDao.toggleFavorite(id, isFav)

    suspend fun deleteCreation(creation: CreationEntity) =
        creationDao.deleteCreation(creation)

    suspend fun deleteById(id: Long) =
        creationDao.deleteById(id)

    suspend fun clearAll() =
        creationDao.clearAll()
}
