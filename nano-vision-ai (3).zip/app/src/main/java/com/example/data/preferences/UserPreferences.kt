package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppThemeMode {
    DARK, LIGHT, SYSTEM
}

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    FRENCH("fr", "Français"),
    ARABIC("ar", "العربية")
}

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nano_vision_prefs", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(
        AppThemeMode.valueOf(prefs.getString("theme_mode", AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name)
    )
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    private val _language = MutableStateFlow(
        AppLanguage.valueOf(prefs.getString("language", AppLanguage.ENGLISH.name) ?: AppLanguage.ENGLISH.name)
    )
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _defaultImageModel = MutableStateFlow(
        prefs.getString("default_image_model", "gemini-2.5-flash-image") ?: "gemini-2.5-flash-image"
    )
    val defaultImageModel: StateFlow<String> = _defaultImageModel.asStateFlow()

    private val _defaultVideoModel = MutableStateFlow(
        prefs.getString("default_video_model", "veo-3.1-fast-generate-preview") ?: "veo-3.1-fast-generate-preview"
    )
    val defaultVideoModel: StateFlow<String> = _defaultVideoModel.asStateFlow()

    private val _defaultAspectRatio = MutableStateFlow(
        prefs.getString("default_aspect_ratio", "1:1") ?: "1:1"
    )
    val defaultAspectRatio: StateFlow<String> = _defaultAspectRatio.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(
        prefs.getBoolean("notifications_enabled", true)
    )
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
        _themeMode.value = mode
    }

    fun setLanguage(lang: AppLanguage) {
        prefs.edit().putString("language", lang.name).apply()
        _language.value = lang
    }

    fun setDefaultImageModel(model: String) {
        prefs.edit().putString("default_image_model", model).apply()
        _defaultImageModel.value = model
    }

    fun setDefaultVideoModel(model: String) {
        prefs.edit().putString("default_video_model", model).apply()
        _defaultVideoModel.value = model
    }

    fun setDefaultAspectRatio(aspect: String) {
        prefs.edit().putString("default_aspect_ratio", aspect).apply()
        _defaultAspectRatio.value = aspect
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("notifications_enabled", enabled).apply()
        _notificationsEnabled.value = enabled
    }
}
