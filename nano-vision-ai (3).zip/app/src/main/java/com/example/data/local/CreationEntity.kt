package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "creations")
data class CreationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val prompt: String,
    val enhancedPrompt: String? = null,
    val mediaType: String, // "IMAGE" or "VIDEO"
    val mediaUrl: String? = null,
    val base64Data: String? = null,
    val modelName: String,
    val modelDisplayName: String,
    val aspectRatio: String = "1:1",
    val style: String? = null,
    val quality: String? = null,
    val durationSeconds: Int = 5,
    val resolution: String = "1080p",
    val hasAudio: Boolean = false,
    val seedImageUri: String? = null,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
